package com.balaai.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 100;
    private TextView status, transcript;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int lang = tts.setLanguage(new Locale("hi", "IN"));
                if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.getDefault());
                }
            }
        });

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { status.setText("सुन रहा हूँ…"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { status.setText("समझ रहा हूँ…"); }
                @Override public void onError(int error) { status.setText("आवाज़ समझ नहीं आई। फिर कोशिश करें।"); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) handleCommand(matches.get(0));
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
        } else {
            status.setText("इस फोन पर Speech Recognition उपलब्ध नहीं है।");
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 48, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF0B1020);

        TextView title = new TextView(this);
        title.setText("BALA AI");
        title.setTextSize(32);
        title.setTextColor(0xFF66D9FF);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("तुम्हारा अपना वॉइस असिस्टेंट");
        subtitle.setTextSize(16);
        subtitle.setTextColor(0xFFFFFFFF);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 12;
        root.addView(subtitle, sp);

        status = new TextView(this);
        status.setText("तैयार हूँ। माइक दबाकर बोलो।");
        status.setTextColor(0xFFB8C7D9);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.topMargin = 30;
        root.addView(status, stp);

        Button listen = new Button(this);
        listen.setText("🎙 बोलो");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = 24;
        root.addView(listen, bp);
        listen.setOnClickListener(v -> startListening());

        transcript = new TextView(this);
        transcript.setTextColor(0xFFFFFFFF);
        transcript.setTextSize(17);
        transcript.setText("यहाँ तुम्हारी बात और BALA का जवाब दिखाई देगा।");
        transcript.setPadding(8, 24, 8, 8);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, 0, 1);
        tp.topMargin = 18;
        root.addView(transcript, tp);

        Button hello = new Button(this);
        hello.setText("BALA से नमस्ते बुलाओ");
        root.addView(hello, new LinearLayout.LayoutParams(-1, -2));
        hello.setOnClickListener(v -> speak("नमस्ते! मैं BALA हूँ। बताओ, मैं तुम्हारी क्या मदद करूँ?"));

        Button settingsNote = new Button(this);
        settingsNote.setText("ऐप खोलने की सुविधा (डेमो)");
        root.addView(settingsNote, new LinearLayout.LayoutParams(-1, -2));
        settingsNote.setOnClickListener(v -> speak("अभी मैं बेसिक डेमो हूँ। ऐप खोलने और AI जवाबों की सुविधा अगले चरण में जोड़ी जाएगी।"));

        setContentView(root);
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (recognizer == null) {
            Toast.makeText(this, "Speech Recognition उपलब्ध नहीं है", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "BALA से बोलें");
        recognizer.startListening(intent);
    }

    private void handleCommand(String command) {
        transcript.setText("तुमने कहा: " + command);
        status.setText("सुना: " + command);
        String lower = command.toLowerCase(Locale.ROOT);

        if (lower.contains("नमस्ते") || lower.contains("hello") || lower.contains("हेलो")) {
            speak("नमस्ते! मैं BALA हूँ।");
        } else if (lower.contains("समय") || lower.contains("time")) {
            java.text.SimpleDateFormat fmt = new java.text.SimpleDateFormat("h:mm a", new Locale("hi", "IN"));
            speak("अभी समय है " + fmt.format(new java.util.Date()));
        } else if (lower.contains("यूट्यूब") || lower.contains("youtube")) {
            openApp("com.google.android.youtube", "YouTube");
        } else if (lower.contains("व्हाट्सऐप") || lower.contains("व्हाट्सएप") || lower.contains("whatsapp")) {
            openApp("com.whatsapp", "WhatsApp");
        } else if (lower.contains("सेटिंग") || lower.contains("settings")) {
            startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
            speak("सेटिंग्स खोल रहा हूँ।");
        } else {
            speak("मैंने सुना: " + command + "। अभी मेरा डेमो मोड है। AI से जुड़े जवाब अगले चरण में जोड़ेंगे।");
        }
    }

    private void openApp(String packageName, String appName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch != null) {
            startActivity(launch);
            speak(appName + " खोल रहा हूँ।");
        } else {
            speak(appName + " इस फोन में इंस्टॉल नहीं है।");
        }
    }

    private void speak(String text) {
        transcript.setText("BALA: " + text);
        status.setText("जवाब दे रहा हूँ…");
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bala_reply");
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
